#ifndef lib_AT91SAM7S256_H
#define lib_AT91SAM7S256_H

/* mthomas: 
   diff between lib_AT91SAM7S64.h and lib_AT91SAM7S256.h
   did not show any significant difference 
   -> save same space in the distribution-archive
*/

#include "lib_AT91SAM7S64.h"

#endif

